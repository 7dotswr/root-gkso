Triple-Layer File Encryption Service v1.0
Description: 
Encrypts and Decrypts your file with ease, allowing for safe file storing.

Features:
Hard to decrypt without knowing key
Long key, lowering chances of potentially cracking through the system through brute-force ways
Also compressing your files

This service is under testing. 